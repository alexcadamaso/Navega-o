import 'package:flutter/material.dart';
import 'package:navegacaopdm/telas/tela_categoria.dart';
import 'package:navegacaopdm/telas/tela_produtos.dart';
import 'package:navegacaopdm/utils/rotas.dart';

void main() {
  runApp(MeuCardapio());
}

class MeuCardapio extends StatelessWidget {
  @override //subscrever metodo para criar elemento de widget
  Widget build(BuildContext context) {
    return MaterialApp(
        title: "Cardápio",
        theme: ThemeData(
          primaryColor: Colors.blue,
        ),
        //home: TelaCategorias(),
        routes: {
          Rotas.HOME: (ctx) => TelaCategorias(),
          Rotas.PRODUTOS: (ctx) => TelaProdutos()
        });
  }
}
