package com.example.navegacaopdm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
